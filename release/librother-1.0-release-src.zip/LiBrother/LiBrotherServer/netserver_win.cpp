#include "config.h"
#include "netserver.h"
#include "session_manager.h"
#include "session.h"
#include "credentials_manager.h"

#include <cassert>
#include <ctime>
#include <cstring>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <algorithm>

//#include <Windows.h>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <MSWSock.h>

#undef X942_DH_PARAMETERS
#undef min
#undef max

#include <liblog.h>
#include <botan/auto_rng.h>
#include <botan/tls_server.h>

MODULE_LOG_NAME("NetServer");

//���������ģ�� - Windowsƽ̨

const size_t BufferSize = 1024;				//���ջ������Ĵ�С
const int Accept_Post_Count = 8;			//ͬʱͶ�ݵ�Accept������
const ULONG_PTR Exit_Key = 0;				//ָʾ�����߳��˳���CompletionKey
const size_t IPLength = 50;
const int WaitTime_WorkerThread = 30;

//��ɶ˿ڴ�������������
enum TIOType
{
	IoAccept,
	IoRecv,
	IoSend
};

//�����̵߳Ĳ���
struct TWorkerThreadParam
{
	CNetServer * pNetServer;
	int nThreadID;
};

//��IO����������
struct TPerIOContext
{
	OVERLAPPED overlapped;
	char buffer[BufferSize];
	WSABUF wsaBuffer;			//Used in IoAccept & IoRecv
	TIOType ioType;
	SOCKET sockClient;			//Used in IoAccept

	TPerIOContext(TIOType ioType) : ioType(ioType)
	{
		memset(&overlapped, 0, sizeof(overlapped));
		wsaBuffer.buf = buffer;
		wsaBuffer.len = BufferSize;
	}
};

//�׽�����չ����
struct TSocketEx
{
	CNetServer * pNetServer;
	//TODO: Use Critical Section to Protect vPIOContexts
	SOCKET socket;			//�׽���
	sockaddr_in client;		//�ͻ���������Ϣ
	bool TLS;				//�Ƿ�ʹ��TLS����
	std::string recvBuffer;	//���������
	bool bReadyToClose;
	bool bIsClientSock;

	TPerIOContext *pIOContextSend, *pIOContextRecv;
	std::set<TPerIOContext *> vPIOContexts;

	std::queue<std::pair<char *, size_t> > qSend;
	CRITICAL_SECTION csIOContext;

	Botan::TLS::Server * pTLSServer;

	unsigned int nRefCount;

	TSocketEx(CNetServer * pNetServer, SOCKET socket, bool bIsClientSock, sockaddr_in client = { 0 }, bool TLS = false) :
		pNetServer(pNetServer), socket(socket), client(client), TLS(TLS), pTLSServer(nullptr), 
		bReadyToClose(false), pIOContextSend(nullptr), pIOContextRecv(nullptr),
		nRefCount(1), bIsClientSock(bIsClientSock)
	{
		//lprintf("SOCKET CONSTRUCT");
		InitializeCriticalSection(&csIOContext);
		if (bIsClientSock)
		{
			EnterCriticalSection((LPCRITICAL_SECTION)pNetServer->m_pcsClientSocks);
			pNetServer->m_vpClientSocks.insert(this);
			LeaveCriticalSection((LPCRITICAL_SECTION)pNetServer->m_pcsClientSocks);
		}
	}

	~TSocketEx()
	{
		lprintf_d("SocketEx Deleted: %p", this);
		DeleteCriticalSection(&csIOContext);
		if (pTLSServer)
		{
			delete pTLSServer;
		}
		while (!qSend.empty())
		{
			char * buffer = qSend.front().first;
			qSend.pop();
			delete buffer;
		}

		if (socket != INVALID_SOCKET)
			closesocket(socket);
		//������IO������
		for (auto i = vPIOContexts.begin(); i != vPIOContexts.end(); ++i)
		{
			if (*i)
				delete (*i);
		}
		if (pIOContextSend)
			delete pIOContextSend;
		if (pIOContextRecv)
			delete pIOContextRecv;
		vPIOContexts.clear();
	}

	//����һ����IO������
	TPerIOContext * createIoContext(TIOType ioType)
	{
		EnterCriticalSection(&csIOContext);
		TPerIOContext * ioContext = nullptr;
		switch (ioType)
		{
		case IoRecv:
			assert(!pIOContextRecv);
			pIOContextRecv = new TPerIOContext(IoRecv);
			ioContext = pIOContextRecv;
			break;
		case IoSend:
			assert(!pIOContextSend);
			pIOContextSend = new TPerIOContext(IoSend);
			ioContext = pIOContextSend;
			break;
		default:
			ioContext = new TPerIOContext(ioType);
			vPIOContexts.insert(ioContext);
		}
		LeaveCriticalSection(&csIOContext);
		return ioContext;
	}

	void eraseIoContext(TPerIOContext * ioContext)
	{
		assert(ioContext);
		EnterCriticalSection(&csIOContext);
		switch (ioContext->ioType)
		{
		case IoRecv:
			assert(ioContext == pIOContextRecv);
			delete pIOContextRecv;
			pIOContextRecv = nullptr;
			break;
		case IoSend:
			assert(ioContext == pIOContextSend);
			delete pIOContextSend;
			pIOContextSend = nullptr;
			break;
		default:
			vPIOContexts.erase(ioContext);
			delete ioContext;
		}
		LeaveCriticalSection(&csIOContext);
	}

	unsigned int AddRef()
	{
		lprintf_d("SocketEx AddRef: %p", this);
		return InterlockedIncrement(&nRefCount);
	}
	unsigned int Release()
	{
		lprintf_d("SocketEx Release: %p", this);
		unsigned int refCount = InterlockedDecrement(&nRefCount);
		if (refCount == 0)
		{
			if (bIsClientSock)
			{
				LPCRITICAL_SECTION csClientSocks = (LPCRITICAL_SECTION)pNetServer->m_pcsClientSocks;
				EnterCriticalSection(csClientSocks);
				pNetServer->m_vpClientSocks.erase(this);
				delete this;
				LeaveCriticalSection(csClientSocks);
			}
			else
				delete this;
		}
		return refCount;
	}

	bool postToSendQueue(const char * pData, size_t nLen, TPerIOContext * &pIOContext)
	{
		assert(pData);
		bool ret = false;
		char * buffer = new char[nLen];
		memcpy_s(buffer, nLen, pData, nLen);
		EnterCriticalSection(&csIOContext);
		if (pIOContextSend)
		{
			ret = true;
			qSend.push(std::make_pair(buffer, nLen));
			pIOContext = pIOContextSend;
		}
		else
		{
			pIOContext = new TPerIOContext(IoSend);
			pIOContext->wsaBuffer.buf = buffer;
			pIOContext->wsaBuffer.len = (ULONG)nLen;
			pIOContextSend = pIOContext;
		}
		LeaveCriticalSection(&csIOContext);
		return ret;
	}
	size_t getSendQueue(char * &buffer)
	{
		size_t sizeBuffer = 0;
		EnterCriticalSection(&csIOContext);
		if (!qSend.empty())
		{
			buffer = qSend.front().first;
			sizeBuffer = qSend.front().second;
			qSend.pop();
		}
		LeaveCriticalSection(&csIOContext);
		return sizeBuffer;
	}
};


CNetServer::CNetServer() :
	m_psockListen(nullptr),
	m_psockListenTLS(nullptr),
	m_hIOCP(NULL),
	m_pCredManager(nullptr),
	m_pPolicy(nullptr),
	m_pTLSSM(nullptr)
{
	m_vhThreads.clear();
	m_pcsClientSocks = new CRITICAL_SECTION;
	m_rng = new Botan::AutoSeeded_RNG;
	m_pSManager = new CSessionManager;
}

CNetServer::~CNetServer()
{
	if (m_pCredManager)
		delete m_pCredManager;
	if (m_pPolicy)
		delete m_pPolicy;
	if (m_pTLSSM)
		delete m_pTLSSM;
	
	delete m_pSManager;
	delete m_rng;
	delete (LPCRITICAL_SECTION)m_pcsClientSocks;
}

bool CNetServer::initNetServer()
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		return false;
	InitializeCriticalSection((LPCRITICAL_SECTION)m_pcsClientSocks);
	return true;
}

bool CNetServer::startServer(ILibClassFactory * pClassFactory)
{
	m_pSManager->startServer(pClassFactory);
	if (!initIOCP())
		return false;
	if (g_configSvr.nTLS && !initTLS())
	{
		if (g_configSvr.nTLS == 2)
			return false;
		g_configSvr.nTLS = 0;
		lprintf_w("TLS will be disabled");
	}
	if (!initListenSocket())
		return false;
	return true;
}

bool CNetServer::stopServer()
{
	EnterCriticalSection((LPCRITICAL_SECTION)m_pcsClientSocks);
	for (auto clientSock : m_vpClientSocks)
	{
		if (!clientSock->bReadyToClose)
			setSocketClose(clientSock);
	}
	LeaveCriticalSection((LPCRITICAL_SECTION)m_pcsClientSocks);

	for (int i = 0; i < m_vhThreads.size(); i++)
		PostQueuedCompletionStatus(m_hIOCP, 0, Exit_Key, nullptr);
	if (WaitForMultipleObjects((DWORD)m_vhThreads.size(), &m_vhThreads[0], TRUE, WaitTime_WorkerThread * 1000) == WAIT_TIMEOUT)
	{
		lprintf_w("Worker Thread Timeout");
		for (auto hThread : m_vhThreads)
		{
			DWORD dwExitCode;
			GetExitCodeThread(hThread, &dwExitCode);
			if (dwExitCode == STILL_ACTIVE)
				TerminateThread(hThread, ~0UL);
		}
	}

	if (!m_vpClientSocks.empty())
	{
		for (auto clientSock : m_vpClientSocks)
			delete clientSock;
	}
	if (g_configSvr.nTLS)
		delete m_psockListenTLS;
	delete m_psockListen;

	m_pSManager->stopServer();
	return true;
}

bool CNetServer::initIOCP()
{
	//TODO: Check Errors
	//������ɶ˿�
	m_hIOCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, 0);
	if (!m_hIOCP)
	{
		DWORD dwLastError = GetLastError();
		lprintf_e("Failed to create IOCP, LAST ERROR %x.", dwLastError);
		return false;
	}

	//��ȡϵͳ�д���������
	SYSTEM_INFO sysInfo;
	GetSystemInfo(&sysInfo);
	int nCPU = sysInfo.dwNumberOfProcessors;

	//���������߳�
	for (int i = 0; i < nCPU * g_configSvr.nThreadPerCPU; i++)
	{
		TWorkerThreadParam * pParam = new TWorkerThreadParam;
		pParam->pNetServer = this;
		pParam->nThreadID = i;
		HANDLE hThread = CreateThread(0, 0, WorkerThread, pParam, 0, 0);
		m_vhThreads.push_back(hThread);
	}

	return true;
}

bool CNetServer::initTLS()
{
	try
	{
		m_pCredManager = new CCredentialsManager(m_rng);
		for (auto cert : g_configSvr.vCerts)
		{
			m_pCredManager->loadCertificate(cert.strCert, cert.strKey, cert.strPassphrase);
		}
		m_pPolicy = new Botan::TLS::Policy;
		m_pTLSSM = new Botan::TLS::Session_Manager_In_Memory(*m_rng);
	}
	catch (std::exception& e)
	{
		lprintf_e("An error occurred while init TLS: \n%s", e.what());
		return false;
	}
	return true;
}

bool CNetServer::createTLSSession(TSocketEx * pSocket)
{
	assert(pSocket);

	try
	{
		//TODO: Handle Alert
		pSocket->pTLSServer = new Botan::TLS::Server(
			[this, pSocket](const Botan::byte * pData, size_t size) { sendData(pSocket, (const char*)pData, size); },
			[this, pSocket](const Botan::byte * pData, size_t size) { receivedData(pSocket, (const char*)pData, size); },
			[](Botan::TLS::Alert alert, const Botan::byte * pData, size_t size) {}, 
			[](const Botan::TLS::Session& session)->bool { return true; },
			*m_pTLSSM, *m_pCredManager, *m_pPolicy, *m_rng);
	}
	catch (std::exception& e)
	{
		lprintf_e("An error occurred while creating TLS Session: \n%s", e.what());
		return false;
	}
	return true;
}

bool CNetServer::initListenSocket()
{
	//���������׽���
	if (!(m_psockListen = createListenSocket(g_configSvr.nPort)))
		return false;
	m_psockListen->TLS = false;

	lprintf("Listen at %d", g_configSvr.nPort);

	//���������׽���(TLS)
	if (g_configSvr.nTLS)
	{
		if (!(m_psockListenTLS = createListenSocket(g_configSvr.nTLSPort)))
			return false;
		m_psockListenTLS->TLS = true;

		lprintf("TLS Listen at %d", g_configSvr.nTLSPort);
	}

	//��ȡAcceptEx��GetAcceptExSockAddrs��ָ��
	GUID guidAcceptEx = WSAID_ACCEPTEX;
	GUID guidGetAcceptExSockAddrs = WSAID_GETACCEPTEXSOCKADDRS;

	DWORD dwRet;
	if (WSAIoctl(m_psockListen->socket, SIO_GET_EXTENSION_FUNCTION_POINTER, &guidAcceptEx, sizeof(guidAcceptEx),
		&m_pfn_AcceptEx, sizeof(m_pfn_AcceptEx), &dwRet, nullptr, nullptr) == SOCKET_ERROR)
		return false;

	if (WSAIoctl(m_psockListen->socket, SIO_GET_EXTENSION_FUNCTION_POINTER, &guidGetAcceptExSockAddrs, sizeof(guidGetAcceptExSockAddrs),
		&m_pfn_GetAcceptExSockAddrs, sizeof(m_pfn_GetAcceptExSockAddrs), &dwRet, nullptr, nullptr) == SOCKET_ERROR)
		return false;

	//Ͷ��Accept�����Խ��ܿͻ�������
	for (int i = 0; i < Accept_Post_Count; i++)
	{
		if (!postAcceptRq(m_psockListen, nullptr))
		{
			if (i == 0)
				return false;
			break;
		}
		if (g_configSvr.nTLS && !postAcceptRq(m_psockListenTLS, nullptr))
		{
			if (i == 0)
				return false;
			break;
		}
	}

	return true;
}

TSocketEx * CNetServer::createListenSocket(int nPort)
{
	sockaddr_in addr;
	SOCKET sockListen;

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(nPort);
	if (inet_pton(AF_INET, g_configSvr.strServerIP.c_str(), &addr.sin_addr) != 1)
		return nullptr;

	sockListen = WSASocket(AF_INET, SOCK_STREAM, 0, nullptr, 0, WSA_FLAG_OVERLAPPED);
	if (sockListen == INVALID_SOCKET)
		return false;

	TSocketEx * sockEx = new TSocketEx(this, sockListen, false);

	if (!CreateIoCompletionPort((HANDLE)sockListen, m_hIOCP, (ULONG_PTR)sockEx, 0))
	{
		delete sockEx;
		closesocket(sockListen);
		return false;
	}

	if (bind(sockListen, (sockaddr *)&addr, sizeof(addr)) != 0)
	{
		delete sockEx;
		closesocket(sockListen);
		return false;
	}

	if (listen(sockListen, SOMAXCONN) != 0)
	{
		delete sockEx;
		closesocket(sockListen);
		return false;
	}

	return sockEx;
}

bool CNetServer::postAcceptRq(TSocketEx * pSocket, TPerIOContext * pIOContext)
{
	assert(pSocket);

	lprintf_d("POST ACCEPT RQ");

	bool bNewIOContext = false;
	if (!pIOContext)
	{
		//��һ�δ���IO������
		pIOContext = pSocket->createIoContext(IoAccept);
		pSocket->AddRef();
		bNewIOContext = true;
	}
	
	SOCKET sockClient = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
	if (sockClient == INVALID_SOCKET)
	{
		pSocket->eraseIoContext(pIOContext);
		pSocket->Release();
		return false;
	}

	DWORD dwBytes;
	if (!(LPFN_ACCEPTEX(m_pfn_AcceptEx))(pSocket->socket, sockClient, pIOContext->wsaBuffer.buf,
		BufferSize - (sizeof(sockaddr_in) + 16) * 2, sizeof(sockaddr_in) + 16, sizeof(sockaddr_in) + 16,
		&dwBytes, (LPOVERLAPPED)pIOContext))
	{
		if (WSAGetLastError() != WSA_IO_PENDING)
		{
			pSocket->eraseIoContext(pIOContext);
			pSocket->Release();
			return false;
		}
	}
	
	pIOContext->sockClient = sockClient;

	return true;
}

bool CNetServer::postRecvRq(TSocketEx * pSocket, TPerIOContext * pIOContext)
{
	assert(pSocket);

	lprintf_d("POST RECV RQ");

	bool bNewIOContext = false;
	
	if (!pIOContext)
	{
		pIOContext = pSocket->createIoContext(IoRecv);
		pSocket->AddRef();
		bNewIOContext = true;
	}

	DWORD dwBytes, dwFlags = 0;
	int nRet = WSARecv(pSocket->socket, &pIOContext->wsaBuffer, 1, &dwBytes, &dwFlags, (LPOVERLAPPED)pIOContext, nullptr);

	if (nRet == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING)
	{
		pSocket->eraseIoContext(pIOContext);
		pSocket->Release();
		return false;
	}

	return true;
}

bool CNetServer::postSendRq(TSocketEx * pSocket, TPerIOContext * pIOContext)
{
	assert(pSocket && pIOContext);

	lprintf_d("POST SEND RQ");

	DWORD dwBytes, dwFlags = 0;
	int nRet = WSASend(pSocket->socket, &pIOContext->wsaBuffer, 1, &dwBytes, 0, (LPOVERLAPPED)pIOContext, nullptr);
	if (nRet == SOCKET_ERROR)
	{
		if (WSAGetLastError() != WSA_IO_PENDING)
		{
			pSocket->eraseIoContext(pIOContext);
			pSocket->Release();
			return false;
		}
	}
	return true;
}

bool CNetServer::sendData(TSocketEx * pSocket, const char * pData, size_t nLen)
{
	while (nLen > 0)
	{
		size_t sizeNow = std::min(nLen, BufferSize);
		TPerIOContext * pIOContext;
		if (!pSocket->postToSendQueue(pData, sizeNow, pIOContext))
		{
			pSocket->AddRef();
			if (!postSendRq(pSocket, pIOContext))
				return false;
		}
		pData += sizeNow;
		nLen -= sizeNow;
	}
	return true;
}

unsigned long WINAPI CNetServer::WorkerThread(void * pParam)
{
	TWorkerThreadParam * param = (TWorkerThreadParam *)pParam;
	CNetServer * netServer = param->pNetServer;
	DWORD dwBytes;
	ULONG_PTR completionKey;
	LPOVERLAPPED pOverlapped;

	while (true)
	{
		BOOL bRet = GetQueuedCompletionStatus(netServer->m_hIOCP, &dwBytes, &completionKey, &pOverlapped, INFINITE);
		TSocketEx * pSocket = (TSocketEx *)completionKey;
		TPerIOContext * pPIOContext = CONTAINING_RECORD(pOverlapped, TPerIOContext, overlapped);
		if (!bRet)
		{
			//TODO: Handle Error
			DWORD dwError = GetLastError();
			
			if (dwError == ERROR_NETNAME_DELETED)
			{
				lprintf("A client closed the connection abnormally");
				pSocket->eraseIoContext(pPIOContext);
				pSocket->Release();
			}
			else
			{
				lprintf_e("An IOCP Error occurred: %d (Thread: %d)", dwError, param->nThreadID);
				break;
			}
			continue;
		}

		if (completionKey == Exit_Key)
			break;

		lprintf_d("IOTYPE=%d", pPIOContext->ioType);

		switch (pPIOContext->ioType)
		{
		case IoAccept:
			netServer->doAccept(pSocket, pPIOContext, dwBytes);
			break;
		case IoRecv:
			netServer->doRecv(pSocket, pPIOContext, dwBytes);
			break;
		case IoSend:
			netServer->doSend(pSocket, pPIOContext, dwBytes);
			break;
		default:
			break;
		}
	}
	delete param;
	return 0;
}

int CNetServer::doAccept(TSocketEx * pSocket, TPerIOContext * pIOContext, size_t nDataSize)
{
	assert(pSocket && pSocket->socket != INVALID_SOCKET);
	assert(pIOContext && pIOContext->sockClient != INVALID_SOCKET);
	
	sockaddr_in *localAddr = nullptr, *remoteAddr = nullptr;
	int sizeLocal = sizeof(localAddr), sizeRemote = sizeof(remoteAddr);

	(LPFN_GETACCEPTEXSOCKADDRS(m_pfn_GetAcceptExSockAddrs))(pIOContext->wsaBuffer.buf,
		BufferSize - 2 * (sizeof(sockaddr_in) + 16),
		sizeof(sockaddr_in) + 16,
		sizeof(sockaddr_in) + 16,
		(sockaddr **)&localAddr, &sizeLocal,
		(sockaddr **)&remoteAddr, &sizeRemote);

	TSocketEx * pClientSocket = new TSocketEx(this, pIOContext->sockClient, true, *remoteAddr, pSocket->TLS);

	char clientIP[IPLength] = { 0 };
	inet_ntop(remoteAddr->sin_family, &remoteAddr->sin_addr, clientIP, sizeof(clientIP));
	lprintf("Accept Connection, IP: %s %s", clientIP, pSocket->TLS ? "(TLS enabled)" : "");

	bool bPostedAcceptRq = postAcceptRq(pSocket, pIOContext);
	if (!bPostedAcceptRq)
	{
		lprintf_e("Failed to Post Accept Request");
	}

	if (pSocket->TLS && !createTLSSession(pClientSocket))
	{
		lprintf_e("Failed to Create TLS Session");
		//delete pClientSocket;
		pClientSocket->Release();
		if (!bPostedAcceptRq)
			return -1;
		return 1;
	}

	if (!CreateIoCompletionPort((HANDLE)pClientSocket->socket, m_hIOCP, (ULONG_PTR)pClientSocket, 0))
	{
		lprintf_e("Failed to Bind Socket to IOCP, Error: %d", GetLastError());
		//delete pClientSocket;
		pClientSocket->Release();
		if (!bPostedAcceptRq)
			return -1;
		return 1;	//Error - Client Socket Error
	}

	//�����ͻ��˷����ĵ�һ������
	recvRawData(pClientSocket, pIOContext->wsaBuffer.buf, nDataSize);

	if (!pClientSocket->bReadyToClose)
	{
		if (!postRecvRq(pClientSocket, nullptr))
		{
			//delete pClientSocket;
			pClientSocket->Release();
			if (!bPostedAcceptRq)
				return -1;
			return 1;
		}
	}
	
	pClientSocket->Release();

	if (!bPostedAcceptRq)
		return -1;
	return 0;	//Success
}

bool CNetServer::doRecv(TSocketEx * pSocket, TPerIOContext * pIOContext, size_t nDataSize)
{
	assert(pSocket && pIOContext);
	lprintf_d("DO RECV, size=%d", nDataSize);

	if (nDataSize == 0)
	{
		//�ر�����
		pSocket->bReadyToClose = true;
		pSocket->eraseIoContext(pIOContext);
		pSocket->Release();
		return true;
	}
	recvRawData(pSocket, pIOContext->wsaBuffer.buf, nDataSize);
	if (pSocket->bReadyToClose)
	{
		lprintf_d("CLOSE CONNECTION");
		pSocket->eraseIoContext(pIOContext);
		pSocket->Release();
		return true;
	}
	return postRecvRq(pSocket, pIOContext);
}

bool CNetServer::doSend(TSocketEx * pSocket, TPerIOContext * pIOContext, size_t nDataSize)
{
	assert(pSocket && pIOContext && pIOContext->wsaBuffer.buf);

	lprintf_d("DO SEND, size=%d", nDataSize);

	delete pIOContext->wsaBuffer.buf;
	char * buffer = nullptr;
	size_t sizeBuffer = pSocket->getSendQueue(buffer);
	if (sizeBuffer == 0)
	{
		pSocket->eraseIoContext(pIOContext);
		pSocket->Release();
		return true;
	}
	pIOContext->wsaBuffer.buf = buffer;
	pIOContext->wsaBuffer.len = (ULONG)sizeBuffer;
	return postSendRq(pSocket, pIOContext);
}

void CNetServer::receivedData(TSocketEx * pSocket, const char * pData, size_t nLen)
{
	assert(pSocket);
	
	int nLine = 0;
	if (!pSocket->recvBuffer.empty() && pSocket->recvBuffer.back() == '\n')
		nLine = 1;
	for (size_t i = 0; i < nLen; i++)
	{
		pSocket->recvBuffer += pData[i];
		if (pData[i] == '\n')
			nLine++;
		else
			nLine = 0;
		if (nLine >= 2)
		{
			nLine = 0;
			pSocket->recvBuffer.erase(pSocket->recvBuffer.size() - 2, 2);
			
			size_t fi, len = pSocket->recvBuffer.length();
			for (fi = 0; fi < len; fi++)
			{
				if (pSocket->recvBuffer[fi] != '\n')
					break;
			}
			if (fi)
				pSocket->recvBuffer = pSocket->recvBuffer.substr(fi);

			char clientIP[IPLength];
			inet_ntop(pSocket->client.sin_family, &pSocket->client.sin_addr, clientIP, sizeof(clientIP));
			std::string strResponse;
			bool bKeepAlive;
			bKeepAlive = m_pSManager->recvRequest(std::string(clientIP), pSocket->recvBuffer, strResponse);
			pSocket->recvBuffer.clear();
			if (!strResponse.empty() && strResponse.back() == '\n')
				strResponse += "\n";
			else
				strResponse += "\n\n";
			sendResponse(pSocket, strResponse);
			if (!bKeepAlive)
				setSocketClose(pSocket);
		}
	}
}

void CNetServer::sendResponse(TSocketEx * pSocket, const std::string& strResponse)
{
	assert(pSocket);

	lprintf_d("SEND RES: [\n%s\n]", strResponse.c_str());
	if (pSocket->TLS)
	{
		assert(pSocket->pTLSServer);
		pSocket->pTLSServer->send(strResponse);
	}
	else
		sendData(pSocket, strResponse.data(), strResponse.size());
}

void CNetServer::recvRawData(TSocketEx * pSocket, const char * pData, size_t nLen)
{
	if (pSocket->TLS)
		pSocket->pTLSServer->received_data((const Botan::byte *)pData, nLen);
	else
		receivedData(pSocket, pData, nLen);
}

void CNetServer::setSocketClose(TSocketEx * pSocket)
{
	if (pSocket->TLS)
		pSocket->pTLSServer->close();
	pSocket->bReadyToClose = true;
}