#ifndef MAINSEARCHLIST
#define MAINSEARCHLIST
#include <QListView>

class MainSearchList : public QListView {


private slots:
    void on_pushButton_clicked();


};


#endif // MAINSEARCHLIST
